"use strict";

sap.ui.define(["sap/ui/core/mvc/Controller"], function (Controller) {
  "use strict";

  /**
   * @namespace be.wl.books.overview.controller
   */
  var Main = Controller.extend("be.wl.books.overview.controller.Main", {
    onInit: function _onInit() {}
  });
  return Main;
});
//# sourceMappingURL=Main.controller.js.map