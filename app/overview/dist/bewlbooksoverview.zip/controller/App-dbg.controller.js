"use strict";

sap.ui.define(["sap/ui/core/mvc/Controller"], function (Controller) {
  "use strict";

  /**
   * @namespace be.wl.books.overview.controller
   */
  var App = Controller.extend("be.wl.books.overview.controller.App", {
    onInit: function _onInit() {}
  });
  return App;
});
//# sourceMappingURL=App.controller.js.map