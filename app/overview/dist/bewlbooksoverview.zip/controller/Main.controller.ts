import Controller from "sap/ui/core/mvc/Controller";

/**
 * @namespace be.wl.books.overview.controller
 */
export default class Main extends Controller {

    /*eslint-disable @typescript-eslint/no-empty-function*/
    public onInit(): void {

    }
}